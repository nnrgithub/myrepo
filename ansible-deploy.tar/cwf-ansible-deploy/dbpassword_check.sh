#!/bin/bash

ORACLE_SID=`cat /etc/oratab |awk -F: '{print $1'}`; export ORACLE_SID
ORACLE_HOME=`cat /etc/oratab|grep $ORACLE_SID|awk -F: '{print $2'}`; export ORACLE_HOME
LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$ORACLE_HOME/lib:/lib:/usr/lib:$ORACLE_HOME/rdbms/; export LD_LIBRARY_PATH
PATH=$PATH:$ORACLE_HOME/bin:.; export PATH

sqlplus /nolog <<EOF
connect / as sysdba
set pagesize 500
set linesize 200
set trimspool on
column "EXPIRE DATE" format a20
select username as "USER NAME", expiry_date as "EXPIRE DATE", account_status
from dba_users
where expiry_date < sysdate+20
and account_status IN ( 'OPEN', 'EXPIRED(GRACE)' )
order by account_status, expiry_date, username;

select username,account_status,expiry_date from dba_users where ACCOUNT_STATUS like 'EXPIRED%' order by 1;

exit
EOF