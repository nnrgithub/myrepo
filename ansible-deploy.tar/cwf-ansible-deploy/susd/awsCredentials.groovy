import groovy.json.JsonSlurperClassic

def call(String environment) {
	costCentre = "ICF"
	region = "eu-west-1"

	def envMap = [
	    "brpfdev1": "np",
	    "brpfsit1": "np",
	    "brpfci1": "np",
	    "brpfsst1": "np",	    
	    "prp1": "np",
	    "prp2": "pr",
	    "prp3": "np"
	]

	awsAccount = envMap."${environment}"

	def awsRoleArnMap = [
	    "pr": "arn:aws:iam::284234763074:role/iamrole-lambda-susd",
	    "np": "arn:aws:iam::104046402197:role/iamrole-lambda-susd"
	]

	roleArn = awsRoleArnMap."${awsAccount}"
	roleSessionName = "${costCentre}SUSD"
		try {
			json = sh(returnStdout: true, 
			      script: "aws sts assume-role --duration-seconds 3600 --role-arn ${roleArn} --role-session-name ${roleSessionName}")
			def jsonData = new JsonSlurperClassic().parseText(json)
			env.AWS_ACCESS_KEY_ID = "${jsonData.Credentials.AccessKeyId}"
			env.AWS_SECRET_ACCESS_KEY = "${jsonData.Credentials.SecretAccessKey}"
			env.AWS_SESSION_TOKEN = "${jsonData.Credentials.SessionToken}"
	    }
	    catch(err) {
	        echo "Assume role for ${roleArn} failed: " + err.toString()
	        throw err
	    }
}

return this;